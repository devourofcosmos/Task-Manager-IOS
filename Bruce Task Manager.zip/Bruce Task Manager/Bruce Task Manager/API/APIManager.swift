import Foundation

// Define a simple model for Giphy Emoji
struct GiphyEmoji: Identifiable {
    let id = UUID()  // Unique identifier for the emoji
    let url: String  // URL of the emoji GIF
}

final class GiphyAPIManager {
    static let shared = GiphyAPIManager()  // Singleton instance
    
    private init() { }  // Private init to enforce singleton
    
    // Function to fetch emojis from the Giphy API
    func fetchEmojis(completion: @escaping ([GiphyEmoji]?, Error?) -> Void) {
        let apiKey = "Q6TY5fh291gXlBH4BKpse05WRUhdJVn1"
        let urlString = "https://api.giphy.com/v2/emoji?api_key=\(apiKey)&limit=10&offset=0"
        
        guard let url = URL(string: urlString) else {
            completion(nil, URLError(.badURL))
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(nil, error)  // Return error if fetching fails
                return
            }
            
            guard let data = data else {
                completion(nil, URLError(.badServerResponse))
                return
            }
            
            do {
                // Parse the JSON response
                let json = try JSONSerialization.jsonObject(with: data, options: [])
                if let jsonDict = json as? [String: Any],
                   let dataArr = jsonDict["data"] as? [[String: Any]] {
                    let emojis = dataArr.compactMap { emojiDict -> GiphyEmoji? in
                        if let images = emojiDict["images"] as? [String: Any],
                           let original = images["original"] as? [String: Any],
                           let url = original["url"] as? String {
                            return GiphyEmoji(url: url)
                        }
                        return nil
                    }
                    completion(emojis, nil)  // Return emojis on success
                }
            } catch {
                completion(nil, error)  // Return error if parsing fails
            }
        }.resume()
    }
}


