import Foundation

struct PopcatGif: Identifiable {
    let id = UUID()
    let url: String  // URL of the GIF
}

final class GiphyAPIManagerForProfile {
    static let shared = GiphyAPIManagerForProfile()  // Singleton instance
    
    private init() {}
    
    func fetchPopcatGif(completion: @escaping ([PopcatGif]?, Error?) -> Void) {
        let apiKey = "Q6TY5fh291gXlBH4BKpse05WRUhdJVn1"
        let urlString = "https://api.giphy.com/v1/gifs/search?api_key=\(apiKey)&q=popcat&limit=1&offset=0&rating=g&lang=en&bundle=messaging_non_clips"
        
        guard let url = URL(string: urlString) else {
            completion(nil, URLError(.badURL))
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(nil, error)
                return
            }
            
            guard let data = data else {
                completion(nil, URLError(.badServerResponse))
                return
            }
            
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
                if let dataArr = json?["data"] as? [[String: Any]] {
                    let gifs = dataArr.compactMap { gifDict -> PopcatGif? in
                        if let images = gifDict["images"] as? [String: Any],
                           let original = images["original"] as? [String: Any],
                           let url = original["url"] as? String {
                            return PopcatGif(url: url)
                        }
                        return nil
                    }
                    completion(gifs, nil)
                }
            } catch {
                completion(nil, error)
            }
        }.resume()
    }
}
