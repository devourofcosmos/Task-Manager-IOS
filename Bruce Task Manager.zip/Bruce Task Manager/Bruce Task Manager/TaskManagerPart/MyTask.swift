//
//  MyTask.swift
//  Bruce Task Manager
//
//  Created by BUC on 16/10/2024.
//

import Foundation
import UIKit
import SwiftUI

// Task model for managing individual tasks.
struct MyTask: Identifiable {
    let id = UUID()  // Unique ID for each task.
    var title: String  // Task title.
    var dueDate: Date  // Task's due date.
    var status: MyTaskStatus  // Task status (pending, completed, failed).
    var color: Color  // Task color for visual indication.
}

// Enum for task statuses.
enum MyTaskStatus: String, CaseIterable {
    case pending
    case completed
    case failed
}

// Enum for categorizing tasks by timing.
enum TaskCategory {
    case today
    case upcoming
    case completed
    case failed
}
