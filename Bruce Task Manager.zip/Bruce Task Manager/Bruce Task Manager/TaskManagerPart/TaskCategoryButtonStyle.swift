//
//  TaskCategoryButtonStyle.swift
//  Bruce Task Manager
//
//  Created by BUC on 16/10/2024.
//

import SwiftUI

struct TaskCategoryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 14))  // Set a slightly smaller font size to fit text better
            .frame(maxWidth: .infinity)  // Ensure the button takes up all available space
            .frame(height: 40)
            .padding(.horizontal, 10)  // Keep padding to ensure the button looks neat
            .background(configuration.isPressed ? Color.gray : Color.black)
            .foregroundColor(.white)
            .cornerRadius(10)
            .padding(5)
    }
}
