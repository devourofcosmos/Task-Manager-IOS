import SwiftUI

struct AddTaskView: View {
    @Environment(\.dismiss) var dismiss  // Handle view dismissal.
    @ObservedObject var viewModel: TaskManagerViewModel  // ViewModel to manage task data.
    @State private var taskTitle: String = ""  // State for task title.
    @State private var taskColor: Color = .yellow  // State for task color.
    @State private var taskType: TaskType = .basic  // State for task type.
    @State private var dueDate: Date = Date()  // State for task due date.

    var body: some View {
        NavigationView {
            VStack(spacing: 24) {
                // Task Color Selection section.
                VStack(alignment: .leading, spacing: 10) {
                    Text("Task Color")
                        .font(.headline)
                    HStack(spacing: 15) {
                        // Selectable color circles.
                        ForEach([Color.yellow, Color.blue, Color.purple, Color.red, Color.orange], id: \.self) { color in
                            Circle()
                                .fill(color)
                                .frame(width: 30, height: 30)
                                .overlay(
                                    Circle().stroke(taskColor == color ? Color.black : Color.clear, lineWidth: 2)
                                )
                                .onTapGesture {
                                    taskColor = color  // Set selected color.
                                }
                        }
                    }
                }

                // Task Deadline selection using DatePicker.
                VStack(alignment: .leading, spacing: 10) {
                    Text("Task Deadline")
                        .font(.headline)
                    DatePicker("", selection: $dueDate, displayedComponents: [.date, .hourAndMinute])
                        .datePickerStyle(CompactDatePickerStyle())  // Compact date picker style.
                }

                // Task Title input field.
                VStack(alignment: .leading, spacing: 10) {
                    Text("Task Title")
                        .font(.headline)
                    TextField("Enter task title", text: $taskTitle)
                        .padding()
                        .background(Color.gray.opacity(0.2))
                        .cornerRadius(10)
                }

                // Task Type selection buttons.
                VStack(alignment: .leading, spacing: 10) {
                    Text("Task Type")
                        .font(.headline)
                    HStack(spacing: 20) {
                        ForEach(TaskType.allCases, id: \.self) { type in
                            Button(action: {
                                taskType = type  // Set selected task type.
                            }) {
                                Text(type.rawValue)
                                    .padding()
                                    .background(taskType == type ? Color.black : Color.clear)
                                    .foregroundColor(taskType == type ? .white : .black)
                                    .cornerRadius(10)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 10)
                                            .stroke(taskType == type ? Color.black : Color.gray, lineWidth: 1)
                                    )
                            }
                        }
                    }
                }

                Spacer()

                // Save Task button.
                Button(action: {
                    viewModel.addTask(title: taskTitle, dueDate: dueDate, color: taskColor)  // Call ViewModel to save the task.
                    dismiss()  // Dismiss the view after saving.
                }) {
                    Text("Save Task")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(width: 200, height: 50)
                        .background(taskTitle.isEmpty ? Color.gray : Color.black)  // Disable if title is empty.
                        .cornerRadius(10)
                }
                .disabled(taskTitle.isEmpty)  // Disable button if the title is empty.
            }
            .padding()
            .navigationTitle("Edit Task")  // Set the title of the navigation bar.
            .toolbar {
                // Cancel button in the navigation bar.
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
        }
    }
}

// Enum to define different task types.
enum TaskType: String, CaseIterable {
    case basic = "Basic"
    case urgent = "Urgent"
    case important = "Important"
}
