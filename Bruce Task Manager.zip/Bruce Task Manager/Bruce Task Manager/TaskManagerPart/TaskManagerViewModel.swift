import SwiftUI
import UIKit
import CoreData

@MainActor
final class TaskManagerViewModel: ObservableObject {
    @Published var tasks: [MyTask] = []
    @Published var filteredTasks: [MyTask] = []
    @Published var selectedCategory: TaskCategory = .today
    
    // Load tasks from Core Data
    func loadTasks() {
        tasks = CoreDataManager.shared.fetchTasks()
        applyCategoryFilter()
    }

    // Save task to Core Data
    func addTask(title: String, dueDate: Date, color: Color, status: MyTaskStatus = .pending) {
        CoreDataManager.shared.saveTask(title: title, dueDate: dueDate, color: color, status: status)
        loadTasks()
    }

    // Delete task from Core Data
    func deleteTask(_ task: MyTask) {
        CoreDataManager.shared.deleteTask(task)
        loadTasks()
    }

    // Filter tasks based on category
    func applyCategoryFilter() {
        let now = Date()
        switch selectedCategory {
        case .today:
            filteredTasks = tasks.filter { Calendar.current.isDateInToday($0.dueDate) && $0.status == .pending }
        case .upcoming:
            filteredTasks = tasks.filter { $0.dueDate > now && $0.status == .pending }
        case .completed:
            filteredTasks = tasks.filter { $0.status == .completed }
        case .failed:
            filteredTasks = tasks.filter { $0.status == .failed }
        }
    }

    func updateTaskStatus(task: MyTask, status: MyTaskStatus) {
        if let index = tasks.firstIndex(where: { $0.id == task.id }) {
            tasks[index].status = status
            loadTasks()
        }
    }
}
