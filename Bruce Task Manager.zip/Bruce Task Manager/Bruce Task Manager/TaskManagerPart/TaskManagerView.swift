import SwiftUI

struct TaskManagerView: View {
    @StateObject private var viewModel = TaskManagerViewModel()
    @State private var showAddTaskView = false

    var body: some View {
        ZStack {
            // Updated background gradient
            LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.2), Color.purple.opacity(0.5)]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)

            VStack(spacing: 24) {
                // Header
                VStack {
                    Text("Welcome Back")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)

                    Text("Here's Today's Update")
                        .font(.title3)
                        .foregroundColor(.white.opacity(0.8))
                }

                // Task Categories with updated colors
                HStack(spacing: 16) {
                    TaskCategoryButton(title: "Today", backgroundColor: Color.green.opacity(0.8), action: {
                        viewModel.selectedCategory = .today
                        viewModel.loadTasks()
                    })

                    TaskCategoryButton(title: "Upcoming", backgroundColor: Color.orange.opacity(0.8), action: {
                        viewModel.selectedCategory = .upcoming
                        viewModel.loadTasks()
                    })

                    TaskCategoryButton(title: "Task Done", backgroundColor: Color.blue.opacity(0.8), action: {
                        viewModel.selectedCategory = .completed
                        viewModel.loadTasks()
                    })

                    TaskCategoryButton(title: "Failed", backgroundColor: Color.red.opacity(0.8), action: {
                        viewModel.selectedCategory = .failed
                        viewModel.loadTasks()
                    })
                }
                .padding(.horizontal)

                // List of tasks
                if viewModel.filteredTasks.isEmpty {
                    Spacer()
                    Text("No tasks found")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                } else {
                    ScrollView {
                        VStack(spacing: 16) {
                            ForEach(viewModel.filteredTasks, id: \.id) { task in
                                TaskCardView(task: task, viewModel: viewModel)
                                    .animation(.easeInOut(duration: 0.3), value: task.status)
                            }
                        }
                        .padding(.horizontal, 16)
                    }
                }

                Spacer()

                // Add Task Button
                Button(action: {
                    showAddTaskView.toggle()
                }, label: {
                    HStack {
                        Image(systemName: "plus")
                        Text("Add Task")
                    }
                    .font(.headline)
                    .frame(width: 220, height: 55)
                    .foregroundColor(.white)
                    .background(Color.black)
                    .cornerRadius(15)
                    .shadow(color: .gray.opacity(0.5), radius: 10, x: 0, y: 5)
                })
                .padding(.bottom, 40)
            }
        }
        .sheet(isPresented: $showAddTaskView) {
            AddTaskView(viewModel: viewModel)
        }
    }

    // Date Formatter for displaying due dates
    private var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter
    }
}

// Custom button for task categories with adjustable color
struct TaskCategoryButton: View {
    let title: String
    let backgroundColor: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.headline)
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .foregroundColor(.white)
                .frame(minWidth: 80)  // Ensures the buttons have enough space to avoid text wrapping
                .background(backgroundColor)
                .cornerRadius(12)
                .shadow(color: .gray.opacity(0.5), radius: 8, x: 0, y: 5)
        }
    }
}

// Task card for displaying individual tasks
struct TaskCardView: View {
    let task: MyTask
    @ObservedObject var viewModel: TaskManagerViewModel

    var body: some View {
        HStack {
            Circle()
                .fill(task.color)
                .frame(width: 20, height: 20)

            VStack(alignment: .leading, spacing: 4) {
                Text(task.title)
                    .font(.headline)
                Text("Due: \(task.dueDate, formatter: dateFormatter)")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }

            Spacer()

            Button(action: {
                viewModel.updateTaskStatus(task: task, status: task.status == .completed ? .failed : .completed)
            }) {
                Text(task.status == .completed ? "Mark Failed" : "Mark Done")
                    .font(.subheadline)
                    .foregroundColor(.white)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(task.status == .completed ? Color.red : Color.green)
                    .cornerRadius(8)
                    .shadow(color: .gray.opacity(0.4), radius: 5, x: 0, y: 3)
            }
            .buttonStyle(BorderlessButtonStyle())  // Ensure button doesn’t interfere with List
        }
        .padding()
        .background(Color.white.opacity(0.9))
        .cornerRadius(12)
        .shadow(color: .gray.opacity(0.3), radius: 5, x: 0, y: 3)
    }

    // Date Formatter for displaying due dates
    private var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter
    }
}

#Preview {
    TaskManagerView()
}
