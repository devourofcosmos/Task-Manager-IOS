import Foundation
import CoreData
import SwiftUI

class CoreDataManager {
    static let shared = CoreDataManager()  // Singleton instance of CoreDataManager.
    
    let persistentContainer: NSPersistentContainer
    
    init() {
        persistentContainer = NSPersistentContainer(name: "TaskModel")  // Initialize Core Data with the model "TaskModel".
        persistentContainer.loadPersistentStores { (description, error) in
            if let error = error {
                fatalError("Unable to initialize Core Data \(error)")
            }
        }
    }
    
    // Function to save a new task into Core Data.
    func saveTask(title: String, dueDate: Date, color: Color, status: MyTaskStatus) {
        let task = TaskEntity(context: persistentContainer.viewContext)
        task.title = title
        task.dueDate = dueDate
        task.color = color.toHexString()  // Convert color to hex string.
        task.status = status.rawValue  // Save status as raw value.
        
        do {
            try persistentContainer.viewContext.save()  // Save the task.
        } catch {
            print("Failed to save task: \(error)")
        }
    }
    
    // Function to fetch tasks from Core Data.
    func fetchTasks() -> [MyTask] {
        let fetchRequest: NSFetchRequest<TaskEntity> = TaskEntity.fetchRequest()
        
        do {
            let taskEntities = try persistentContainer.viewContext.fetch(fetchRequest)  // Fetch tasks.
            return taskEntities.map { entity in
                MyTask(
                    title: entity.title ?? "",
                    dueDate: entity.dueDate ?? Date(),
                    status: MyTaskStatus(rawValue: entity.status ?? "") ?? .pending,
                    color: Color(hex: entity.color ?? "#FFFFFF")  // Convert hex string back to Color.
                )
            }
        } catch {
            print("Failed to fetch tasks: \(error)")
            return []
        }
    }
    
    // Function to delete a task from Core Data.
    func deleteTask(_ task: MyTask) {
        let fetchRequest: NSFetchRequest<TaskEntity> = TaskEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "title == %@", task.title)  // Find the task by title.
        
        do {
            let taskEntities = try persistentContainer.viewContext.fetch(fetchRequest)
            for entity in taskEntities {
                persistentContainer.viewContext.delete(entity)  // Delete the task.
            }
            try persistentContainer.viewContext.save()
        } catch {
            print("Failed to delete task: \(error)")
        }
    }
}
