//
//  Bruce_Task_ManagerApp.swift
//  Bruce Task Manager
//
//  Created by BUC on 13/10/2024.
//

import SwiftUI
import Firebase
import FirebaseCore


@main
struct Bruce_Task_ManagerApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @State var showSignInView: Bool = false
    init() {
    }
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                AuthenticationView(showSignInView: $showSignInView)
            }
        }
    }
}

class AppDelegate: NSObject, UIApplicationDelegate {
  func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
    FirebaseApp.configure()
    return true
  }
}

