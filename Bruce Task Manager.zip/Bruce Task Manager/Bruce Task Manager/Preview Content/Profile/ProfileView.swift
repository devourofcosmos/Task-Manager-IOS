import SwiftUI

@MainActor
final class ProfileViewModel: ObservableObject {
    @Published private(set) var user: AuthDataResultModel? = nil
    @Published var popcatGifs: [PopcatGif] = []  // To store the fetched Popcat GIFs
    
    func loadCurrentUser() throws {
        self.user = try AuthenticationManager.shared.getAuthenticatedUser()
    }
    
    // Function to fetch Popcat GIF
    func fetchPopcatGif() {
        GiphyAPIManagerForProfile.shared.fetchPopcatGif { [weak self] gifs, error in
            if let error = error {
                print("Error fetching Popcat GIF: \(error)")
                return
            }
            DispatchQueue.main.async {
                self?.popcatGifs = gifs ?? []
            }
        }
    }
}

// Profile view displaying user information, Popcat GIFs, and navigation options.
struct ProfileView: View {
    @StateObject private var viewModel = ProfileViewModel()  // ViewModel for the profile logic.
    @Binding var showSignInView: Bool  // Binding to control showing the sign-in view.

    var body: some View {
        ZStack {
            // Background gradient with subtle colors.
            LinearGradient(gradient: Gradient(colors: [Color.purple.opacity(0.3), Color.blue.opacity(0.4)]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 40) {  // Vertical layout with spacing between elements.
                // Profile container for displaying Popcat GIF and user info.
                VStack(spacing: 20) {
                    // Display the first Popcat GIF if available.
                    if let popcatGif = viewModel.popcatGifs.first {
                        AsyncImage(url: URL(string: popcatGif.url)) { image in
                            image
                                .resizable()
                                .scaledToFit()  // Fit the image inside the specified frame.
                                .frame(width: 150, height: 150)  // Set image size.
                                .cornerRadius(12)
                                .shadow(color: .gray.opacity(0.4), radius: 10, x: 0, y: 5)  // Add shadow to the image.
                        } placeholder: {
                            ProgressView()  // Show loading indicator while the image is loading.
                        }
                    } else {
                        // Placeholder text when no GIF is available.
                        Text("Loading Popcat GIF...")
                            .foregroundColor(.white)
                            .font(.headline)
                    }
                    
                    // Display user information like UID if the user is available.
                    if let user = viewModel.user {
                        Text("User ID: \(user.uid)")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                            .background(Color.black.opacity(0.6))  // Background for user info.
                            .cornerRadius(12)
                            .shadow(color: .black.opacity(0.3), radius: 5, x: 0, y: 3)
                    }
                }
                .padding()
                .background(Color.white.opacity(0.15))  // Semi-transparent background for the profile section.
                .cornerRadius(20)
                .shadow(color: .gray.opacity(0.5), radius: 10, x: 0, y: 5)
                
                // Navigation button to go to the Task Manager view.
                NavigationLink(destination: TaskManagerView()) {
                    Text("Go to Task Manager")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)  // Make the button span the full width.
                        .background(Color.blue)
                        .cornerRadius(12)
                        .shadow(color: .gray.opacity(0.5), radius: 8, x: 0, y: 5)
                }
                .padding(.horizontal, 20)  // Add horizontal padding to the button.

                Spacer()  // Spacer to push elements up.
            }
            .padding(.top, 50)  // Padding from the top to space out the elements.
        }
        // When the view appears, load the current user and fetch Popcat GIFs.
        .onAppear {
            try? viewModel.loadCurrentUser()
            viewModel.fetchPopcatGif()
        }
        // Set the navigation title for the profile view.
        .navigationTitle("Profile")
        // Toolbar item to navigate to settings.
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                NavigationLink {
                    SettingsView(showSignInView: $showSignInView)
                } label: {
                    Image(systemName: "gear")  // Settings icon.
                        .font(.headline)
                        .foregroundColor(.white)
                }
            }
        }
    }
}

// Preview provider for ProfileView.
struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView(showSignInView: .constant(false))  
    }
}
