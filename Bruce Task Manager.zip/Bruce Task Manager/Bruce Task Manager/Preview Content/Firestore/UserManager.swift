import Foundation
import FirebaseFirestore

// Singleton class for managing user data in Firestore.
final class UserManager {
    static let shared = UserManager()  // Shared instance for singleton pattern.
    private init() {}  // Private initializer to prevent external instantiation.
    
    // Function to create a new user in Firestore using the authentication result.
    func createNewUser(auth: AuthDataResultModel) async throws {
        // Data dictionary to store user info in Firestore.
        var userData: [String: Any] = [
            "user_id": auth.uid,  // User ID.
            "date_created": Timestamp(),  // Creation date as Firestore timestamp.
        ]
        // Optionally add email if available.
        if let email = auth.email {
            userData["email"] = email
        }
        // Optionally add photo URL if available.
        if let photoUrl = auth.photoUrl {
            userData["photo_url"] = photoUrl
        }
        // Save user data in the "users" collection in Firestore with the user's UID as the document ID.
        try await Firestore.firestore().collection("users").document(auth.uid).setData(userData, merge: false)
    }
}
