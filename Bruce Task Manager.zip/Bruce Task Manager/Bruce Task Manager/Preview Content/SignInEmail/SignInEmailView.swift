import SwiftUI

// SwiftUI view for signing in or signing up with email and password.
struct SignInEmailView: View {
    @StateObject private var viewModel = SignInEmailViewModel()  // Initialize the ViewModel.
    @Binding var showSignInView: Bool  // Binding to control whether the sign-in view is shown or hidden.

    var body: some View {
        VStack {
            // Email input field.
            TextField("Email...", text: $viewModel.email)
                .padding()
                .background(Color.gray.opacity(0.4))  // Gray background for input field.
                .cornerRadius(10)

            // Password input field (secured).
            SecureField("Password...", text: $viewModel.password)
                .padding()
                .background(Color.gray.opacity(0.4))  // Gray background for input field.
                .cornerRadius(10)

            // Sign-up button.
            Button {
                Task {
                    do {
                        try await viewModel.signUp()  // Attempt to sign up the user.
                        showSignInView = false  // Hide the sign-in view on success.
                    } catch {
                        print(error)  // Print any errors that occur during sign-up.
                    }
                }
            } label: {
                Text("Sign Up")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(height: 55)
                    .frame(maxWidth: .infinity)
                    .background(Color.green)  // Green background for the sign-up button.
                    .cornerRadius(10)
            }

            Spacer()  // Pushes the UI components upwards.
        }
        .padding()
        .navigationTitle("Sign In With Email")  // Set the navigation title.
    }
}

// Preview provider for SignInEmailView.
struct SignInEmailView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            SignInEmailView(showSignInView: .constant(false))  // Provide a constant Binding for preview.
        }
    }
}
