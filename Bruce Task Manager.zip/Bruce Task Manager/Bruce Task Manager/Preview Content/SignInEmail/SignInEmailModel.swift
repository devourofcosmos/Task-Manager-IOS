import Foundation

@MainActor
final class SignInEmailViewModel: ObservableObject {
    @Published var email = ""  // Stores the email input from the user.
    @Published var password = ""  // Stores the password input from the user.
    @Published var emojis: [GiphyEmoji] = []  // Stores emojis fetched from Giphy API.
        
    // Function to fetch emojis using the Giphy API manager.
    func fetchEmojis() {
        GiphyAPIManager.shared.fetchEmojis { [weak self] (emojis, error) in
            if let error = error {
                print("Error fetching emojis: \(error.localizedDescription)")
                return
            }
            DispatchQueue.main.async {
                self?.emojis = emojis ?? []  // Update the emojis array on the main thread.
            }
        }
    }
    
    // Function to sign in anonymously.
    func signInAnonymous() async throws {
        try await AuthenticationManager.shared.signInAnonymous()  // Call the authentication manager for anonymous sign-in.
    }

    // Function to sign in a user using email and password.
    func signIn() async throws {
        // Ensure email and password fields are not empty.
        guard !email.isEmpty, !password.isEmpty else {
            print("Email or password cannot be empty.")
            return
        }
        try await AuthenticationManager.shared.signInUser(email: email, password: password)  // Sign in using provided credentials.
    }

    // Function to sign up a new user using email and password.
    func signUp() async throws {
        // Ensure email and password fields are not empty.
        guard !email.isEmpty, !password.isEmpty else {
            print("Email or password cannot be empty.")
            return
        }
        try await AuthenticationManager.shared.createUser(email: email, password: password)  // Create a new user in Firebase.
    }
}
