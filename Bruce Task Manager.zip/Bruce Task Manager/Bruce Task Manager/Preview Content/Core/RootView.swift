import SwiftUI

// Root view that handles the display of ProfileView or AuthenticationView based on user's authentication status.
struct RootView: View {
    @State private var showSignInView: Bool = false  // State to track if the sign-in view should be displayed.

    var body: some View {
        ZStack {
            // Conditionally show the ProfileView if the user is authenticated.
            if !showSignInView {
                NavigationStack {
                    ProfileView(showSignInView: $showSignInView)  // Navigate to ProfileView after successful login.
                }
            }
        }
        // Action when the view appears. It checks if the user is authenticated.
        .onAppear {
            // Try to fetch the currently authenticated user.
            let authUser = try? AuthenticationManager.shared.getAuthenticatedUser()
            // Show sign-in view if there is no authenticated user.
            self.showSignInView = authUser == nil
        }
        // Present the AuthenticationView as a full-screen modal if the user is not signed in.
        .fullScreenCover(isPresented: $showSignInView) {
            NavigationStack {
                AuthenticationView(showSignInView: $showSignInView)  // Sign-in view for authentication.
            }
        }
    }
}

#Preview {
    RootView()  // Preview the RootView in Xcode's canvas.
}
