import SwiftUI

// SwiftUI view for displaying and managing tasks.
struct AppTaskView: View {
    @State private var tasks: [AppTask] = []  // State to store fetched tasks.

    var body: some View {
        List {
            // Loop through the tasks and display them in a list.
            ForEach(tasks) { task in
                Text(task.title)
                    .strikethrough(task.isCompleted)  // Strike through the text if the task is completed.
            }
        }
        .onAppear {
            // Fetch tasks for the current user when the view appears.
            fetchTasksForCurrentUser()
        }
    }

    // Function to fetch tasks for the authenticated user.
    func fetchTasksForCurrentUser() {
        DispatchQueue.main.async {
            Task {
                do {
                    let authUser = try AuthenticationManager.shared.getAuthenticatedUser()  // Get the authenticated user.
                    self.tasks = try await AppTaskManager.shared.fetchTasks(forUserId: authUser.uid)  // Fetch tasks for the user's ID.
                } catch {
                    print("Error fetching tasks: \(error)")  // Print any errors during task fetching.
                }
            }
        }
    }
}
