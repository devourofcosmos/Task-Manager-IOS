import FirebaseFirestore

// Singleton class for managing tasks in Firestore.
final class AppTaskManager {
    static let shared = AppTaskManager()  // Singleton instance.
    private init() {}

    private let db = Firestore.firestore()  // Firestore database reference.

    // Function to create a new task in Firestore.
    func createTask(task: AppTask) async throws {
        try await db.collection("tasks").document(task.id).setData([
            "title": task.title,
            "isCompleted": task.isCompleted,
            "userId": task.userId,
            "dateCreated": task.dateCreated
        ])
    }

    // Function to fetch tasks for a specific user by their user ID.
    func fetchTasks(forUserId userId: String) async throws -> [AppTask] {
        let snapshot = try await db.collection("tasks")
            .whereField("userId", isEqualTo: userId)  // Fetch tasks where the userId matches.
            .order(by: "dateCreated", descending: false)  // Order by creation date.
            .getDocuments()

        return snapshot.documents.compactMap { document in
            try? document.data(as: AppTask.self)  // Map documents to AppTask models.
        }
    }

    // Function to update an existing task in Firestore.
    func updateTask(task: AppTask) async throws {
        try await db.collection("tasks").document(task.id).updateData([
            "title": task.title,
            "isCompleted": task.isCompleted
        ])
    }

    // Function to delete a task from Firestore by its task ID.
    func deleteTask(taskId: String) async throws {
        try await db.collection("tasks").document(taskId).delete()
    }
}
