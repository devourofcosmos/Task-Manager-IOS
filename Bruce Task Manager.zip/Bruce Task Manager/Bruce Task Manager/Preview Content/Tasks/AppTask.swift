import Foundation

// Model representing a task, conforming to Identifiable and Codable for use in SwiftUI and Firebase.
struct AppTask: Identifiable, Codable {
    var id: String = UUID().uuidString  // Unique ID for the task.
    var title: String  // Task title.
    var isCompleted: Bool = false  // Boolean to track if the task is completed.
    var userId: String  // User ID to associate the task with a specific user.
    var dateCreated: Date = Date()  // Timestamp for when the task was created.
}
