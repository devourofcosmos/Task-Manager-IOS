import SwiftUI

// Struct to handle error messages with an identifiable ID for alerts.
struct ErrorMessage: Identifiable {
    var id = UUID()  // Unique identifier for the error message
    var message: String  // Error message content
}

// Main view for handling user authentication (sign in, sign up).
struct AuthenticationView: View {
    @StateObject private var viewModel = SignInEmailViewModel()  // Initialize the ViewModel that manages authentication logic.
    @Binding var showSignInView: Bool  // Bind to show or hide the sign-in view externally.
    @State private var isSigningUp: Bool = true  // Toggle between Sign Up and Sign In views.
    @State private var errorMessage: ErrorMessage?  // Holds any error messages to show in alerts.
    @State private var showSignUpSuccess: Bool = false  // Controls showing the success message after sign-up.

    var body: some View {
        ZStack {
            // Background gradient from blue to purple.
            LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.5), Color.purple.opacity(0.6)]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)  // Ensure the gradient fills the entire screen.

            VStack(spacing: 30) {
                // Dynamic app title that changes based on sign-up or sign-in mode.
                Text(isSigningUp ? "Create Account" : "Welcome Back!")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding(.top, 60)

                // Email input field.
                TextField("Email...", text: $viewModel.email)
                    .padding()
                    .background(Color.white.opacity(0.9))  // Light background for readability.
                    .cornerRadius(15)
                    .shadow(color: .gray.opacity(0.4), radius: 5, x: 0, y: 2)

                // Password input field (secured).
                SecureField("Password...", text: $viewModel.password)
                    .padding()
                    .background(Color.white.opacity(0.9))
                    .cornerRadius(15)
                    .shadow(color: .gray.opacity(0.4), radius: 5, x: 0, y: 2)

                // Button for either Sign Up or Sign In based on toggle.
                Button {
                    Task {
                        do {
                            if isSigningUp {
                                try await viewModel.signUp()  // Attempt to sign up the user.
                                showSignUpSuccess = true  // Trigger success notification.
                            } else {
                                try await viewModel.signIn()  // Sign in the user.
                            }
                            showSignInView = false  // Hide the sign-in view after success.
                        } catch {
                            errorMessage = ErrorMessage(message: error.localizedDescription)  // Capture any error.
                        }
                    }
                } label: {
                    Text(isSigningUp ? "Sign Up" : "Sign In")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(height: 55)
                        .frame(maxWidth: .infinity)
                        .background(isSigningUp ? Color.green.gradient : Color.blue.gradient)  // Dynamic button color.
                        .cornerRadius(15)
                        .shadow(color: .gray.opacity(0.5), radius: 8, x: 0, y: 2)
                }
                .padding(.horizontal)

                // Button to sign in anonymously.
                Button(action: {
                    Task {
                        do {
                            try await viewModel.signInAnonymous()  // Attempt anonymous sign-in.
                            showSignInView = false  // Hide the sign-in view after success.
                        } catch {
                            errorMessage = ErrorMessage(message: error.localizedDescription)  // Capture any error.
                        }
                    }
                }, label: {
                    Text("Sign In Anonymously")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(height: 55)
                        .frame(maxWidth: .infinity)
                        .background(Color.orange.gradient)  // Orange background for anonymous sign-in.
                        .cornerRadius(15)
                        .shadow(color: .gray.opacity(0.5), radius: 8, x: 0, y: 2)
                })
                .padding(.horizontal)

                // Toggle between Sign Up and Sign In modes.
                Button {
                    isSigningUp.toggle()  // Switch modes.
                } label: {
                    Text(isSigningUp ? "Already have an account? Sign In" : "New user? Sign Up")
                        .font(.subheadline)
                        .foregroundColor(.white)
                        .padding(.top, 20)
                }

                Spacer()

                // Display emojis (e.g., from Giphy API) if available.
                if !viewModel.emojis.isEmpty {
                    Text("☝( ◠‿◠ )☝")  // Emoji header text.
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(.top, 20)

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 20) {
                            // Iterate through emojis and display each one asynchronously.
                            ForEach(viewModel.emojis) { emoji in
                                AsyncImage(url: URL(string: emoji.url)) { image in
                                    image
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 60, height: 60)  // Set the size for emoji images.
                                } placeholder: {
                                    ProgressView()  // Show a loading indicator while the emoji is being fetched.
                                }
                            }
                        }
                        .padding()
                    }
                } else {
                    Text("Loading Emojis...")  // Placeholder text while emojis are being loaded.
                        .foregroundColor(.white)
                        .padding()
                }
            }
            .padding(.horizontal, 30)  // Horizontal padding for the VStack layout.
        }
        // Alert for displaying error messages.
        .alert(item: $errorMessage) { errorMessage in
            Alert(title: Text("Error"), message: Text(errorMessage.message), dismissButton: .default(Text("OK")))
        }
        // Alert to show after successful sign-up.
        .alert(isPresented: $showSignUpSuccess) {
            Alert(
                title: Text("Sign Up Successful!"),
                message: Text("Your account has been created. Please sign in."),
                dismissButton: .default(Text("Go to Sign In")) {
                    isSigningUp = false  // Switch to Sign In mode after success.
                }
            )
        }
        // Trigger fetching of emojis when the view appears.
        .onAppear {
            viewModel.fetchEmojis()  // Fetch emojis via ViewModel when the view is loaded.
        }
    }
}

struct AuthenticationView_Previews: PreviewProvider {
    static var previews: some View {
        AuthenticationView(showSignInView: .constant(false))  // Preview with a constant Binding for the sign-in view.
    }
}
