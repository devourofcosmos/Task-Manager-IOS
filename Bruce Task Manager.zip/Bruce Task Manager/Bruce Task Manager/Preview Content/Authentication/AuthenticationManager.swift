import Foundation
import FirebaseAuth

// Model to store authenticated user data such as uid, email, and photoUrl.
struct AuthDataResultModel {
    let uid: String
    let email: String?
    let photoUrl: String?
    
    // Initialize the model with data from the Firebase User object.
    init(user: User) {
        self.uid = user.uid
        self.email = user.email
        self.photoUrl = user.photoURL?.absoluteString
    }
}

// Singleton class to manage all authentication-related tasks using Firebase.
final class AuthenticationManager {
    // Static instance for shared use of the authentication manager across the app.
    static let shared = AuthenticationManager()
    
    // Private initializer to enforce singleton pattern.
    private init() { }
    
    // Function to retrieve the currently authenticated user.
    func getAuthenticatedUser() throws -> AuthDataResultModel {
        // Ensure that there is a current user, otherwise throw an error.
        guard let user = Auth.auth().currentUser else {
            throw URLError(.badServerResponse)
        }
        // Return user data as an AuthDataResultModel.
        return AuthDataResultModel(user: user)
    }

    // Function to create a new user account with email and password.
    @discardableResult
    func createUser(email: String, password: String) async throws -> AuthDataResultModel {
        // Create user in Firebase and get authentication result.
        let authDataResult = try await Auth.auth().createUser(withEmail: email, password: password)
        // Convert Firebase user data into a structured model.
        let userData = AuthDataResultModel(user: authDataResult.user)
        // Call to UserManager to store additional user data.
        try await UserManager.shared.createNewUser(auth: userData)
        return userData
    }

    // Function to sign in an existing user with email and password.
    @discardableResult
    func signInUser(email: String, password: String) async throws -> AuthDataResultModel {
        // Sign in user in Firebase and get authentication result.
        let authDataResult = try await Auth.auth().signIn(withEmail: email, password: password)
        // Return the user data as AuthDataResultModel.
        return AuthDataResultModel(user: authDataResult.user)
    }

    // Function to send a password reset email to the given address.
    func resetPassword(email: String) async throws {
        // Use Firebase's password reset functionality.
        try await Auth.auth().sendPasswordReset(withEmail: email)
    }

    // Function to update the currently authenticated user's password.
    func updatePassword(password: String) async throws {
        // Ensure a user is signed in, otherwise throw an error.
        guard let user = Auth.auth().currentUser else {
            throw URLError(.badServerResponse)
        }
        // Update the password for the authenticated user.
        try await user.updatePassword(to: password)
    }

    // Function to update the currently authenticated user's email.
    func updateEmail(email: String) async throws {
        // Ensure a user is signed in, otherwise throw an error.
        guard let user = Auth.auth().currentUser else {
            throw URLError(.badServerResponse)
        }
        // Update the email for the authenticated user.
        try await user.updateEmail(to: email)
    }

    // Function to sign out the currently authenticated user.
    func signOut() throws {
        // Use Firebase's sign out functionality.
        try Auth.auth().signOut()
    }

    // Function to sign in anonymously (no email/password required).
    @discardableResult
    func signInAnonymous() async throws -> AuthDataResultModel {
        // Sign in anonymously using Firebase's anonymous sign-in feature.
        let authDataResult = try await Auth.auth().signInAnonymously()
        // Convert Firebase user data into a structured model.
        let userData = AuthDataResultModel(user: authDataResult.user)
        // Call to UserManager to store anonymous user data.
        try await UserManager.shared.createNewUser(auth: userData)
        return userData
    }
}
