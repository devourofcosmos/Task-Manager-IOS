import SwiftUI

@MainActor
final class SettingsViewModel: ObservableObject {
    // Function to sign out the user.
    func signOut() throws {
        try AuthenticationManager.shared.signOut()
    }

    // Function to reset the user's password by sending a reset email.
    func resetPassword() async throws {
        let authUser = try AuthenticationManager.shared.getAuthenticatedUser()  // Fetch the authenticated user.
        guard let email = authUser.email else {
            throw URLError(.fileDoesNotExist)  // Throw error if email is not found.
        }
        try await AuthenticationManager.shared.resetPassword(email: email)  // Send password reset email.
    }

    // Function to update the user's email.
    func updateEmail() async throws {
        let email = "hello123@gmail.com"  // Dummy email to demonstrate updating.
        try await AuthenticationManager.shared.updateEmail(email: email)  // Update email.
    }

    // Function to update the user's password.
    func updatePassword() async throws {
        let password = "Hello123!"  // Dummy password to demonstrate updating.
        try await AuthenticationManager.shared.updatePassword(password: password)  // Update password.
    }
}

struct SettingsView: View {
    @StateObject private var viewModel = SettingsViewModel()  // Instantiate the SettingsViewModel.
    @Binding var showSignInView: Bool  // Binding to control when to show the sign-in view.
    @State private var showAlert = false  // State for showing alert notifications.
    @State private var alertMessage = ""  // State for the content of the alert message.

    var body: some View {
        ZStack {
            // Background gradient with soft colors.
            LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.3), Color.purple.opacity(0.4)]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 30) {
                // Button for signing out.
                Button(action: {
                    Task {
                        do {
                            try viewModel.signOut()  // Sign out the user.
                            showSignInView = true  // Show the sign-in view.
                        } catch {
                            alertMessage = "Failed to sign out"  // Handle error.
                            showAlert = true
                        }
                    }
                }) {
                    SettingsButtonLabel(title: "Log out")  // Custom button label.
                }

                // Button to reset the password.
                Button(action: {
                    Task {
                        do {
                            try await viewModel.resetPassword()  // Send a password reset email.
                            alertMessage = "Password reset email sent!"  // Success message.
                            showAlert = true
                        } catch {
                            alertMessage = "Failed to reset password"  // Error message.
                            showAlert = true
                        }
                    }
                }) {
                    SettingsButtonLabel(title: "Reset Password")
                }

                // Button to update the password.
                Button(action: {
                    Task {
                        do {
                            try await viewModel.updatePassword()  // Update password.
                            alertMessage = "Password updated!"  // Success message.
                            showAlert = true
                        } catch {
                            alertMessage = "Failed to update password"  // Error message.
                            showAlert = true
                        }
                    }
                }) {
                    SettingsButtonLabel(title: "Update Password")
                }

                // Button to update the email.
                Button(action: {
                    Task {
                        do {
                            try await viewModel.updateEmail()  // Update email.
                            alertMessage = "Email updated!"  // Success message.
                            showAlert = true
                        } catch {
                            alertMessage = "Failed to update email"  // Error message.
                            showAlert = true
                        }
                    }
                }) {
                    SettingsButtonLabel(title: "Update Email")
                }

                Spacer()  // Spacer to push content to the top.
            }
            .padding(.top, 50)
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Notification"), message: Text(alertMessage), dismissButton: .default(Text("OK")))  // Show alerts for actions.
            }
        }
        .navigationTitle("Settings")  // Title for the navigation bar.
    }
}

// Reusable custom button label to maintain a consistent style.
struct SettingsButtonLabel: View {
    let title: String
    
    var body: some View {
        Text(title)
            .font(.headline)
            .foregroundColor(.white)
            .frame(height: 55)
            .frame(maxWidth: .infinity)
            .background(Color.blue)
            .cornerRadius(12)
            .shadow(color: .gray.opacity(0.5), radius: 8, x: 0, y: 3)
            .padding(.horizontal, 20)
    }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            SettingsView(showSignInView: .constant(false))
        }
    }
}
