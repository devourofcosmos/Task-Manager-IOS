//
//  Bruce_Task_ManagerTests.swift
//  Bruce Task ManagerTests
//
//  Created by BUC on 13/10/2024.
//

import Testing
@testable import Bruce_Task_Manager

struct Bruce_Task_ManagerTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
